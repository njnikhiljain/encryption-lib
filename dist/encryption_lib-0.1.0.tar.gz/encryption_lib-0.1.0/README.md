# Encryption Library

A simple encryption library for projects.

## Installation

```bash
pip install encryption-lib
